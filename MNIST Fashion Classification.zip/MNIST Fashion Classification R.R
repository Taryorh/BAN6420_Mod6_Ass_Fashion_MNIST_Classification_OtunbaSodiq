# Load the keras package
library(keras)

# Load the Fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()

# Split data into training and test sets
c(train_images, train_labels) %<-% fashion_mnist$train
c(test_images, test_labels) %<-% fashion_mnist$test

# Reshape the images to add the channel dimension
train_images <- array_reshape(train_images, c(nrow(train_images), 28, 28, 1))
test_images <- array_reshape(test_images, c(nrow(test_images), 28, 28, 1))

# Normalize the pixel values to be between 0 and 1
train_images <- train_images / 255
test_images <- test_images / 255


# Convert labels to one-hot encoding (without the `y` argument)
train_labels <- to_categorical(train_labels, num_classes = 10)
test_labels <- to_categorical(test_labels, num_classes = 10)


# Define the model
model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = 'relu', 
                input_shape = c(28, 28, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = 'relu') %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_flatten() %>%
  layer_dense(units = 128, activation = 'relu') %>%
  layer_dense(units = 10, activation = 'softmax')

# Print model summary
summary(model)

# Compile the model
model %>% compile(
  optimizer = 'adam',
  loss = 'categorical_crossentropy',
  metrics = c('accuracy')
)

# Train the model
history <- model %>% fit(
  train_images, train_labels,
  epochs = 10,
  batch_size = 64,
  validation_split = 0.2
)

# Evaluate the model on the test dataset
score <- model %>% evaluate(test_images, test_labels)
cat('Test loss:', score[[1]], '\n')
cat('Test accuracy:', score[[2]], '\n')

# Make predictions on the test data
predictions <- model %>% predict(test_images)

# Display the first prediction
print(predictions[1,])

